const s=globalThis.__sveltekit_11umylu?.base??"/givememydata",a=globalThis.__sveltekit_11umylu?.assets??s;export{a,s as b};
